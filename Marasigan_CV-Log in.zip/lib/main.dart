import 'package:flutter/material.dart';
import 'Login.dart'; // Login Page
import 'SignUp.dart'; // Sign Up Page
import 'Marasigan_Cv.dart'; // Marasigan Cv Page

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My CV',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',
      routes: {
        '/': (context) => const LoginPage(), // Login Route
        '/signup': (context) => const SignUpPage(), // Sign Up Route
        '/cv': (context) => const CVPage(), // Marasigan CV Route
      },
    );
  }
}
