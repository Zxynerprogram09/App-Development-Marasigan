package com.example.marasigan_cv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
