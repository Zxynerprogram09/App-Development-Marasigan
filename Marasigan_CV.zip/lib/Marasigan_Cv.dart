import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My CV',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const CVPage(),
    );
  }
}

class CVPage extends StatelessWidget {
  const CVPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My CV'),
      ),
      body: Row(
        children: [
          // Profile Section
          Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey[200],
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.blue[100],
                    child: const Text(
                      "XE",
                      style: TextStyle(fontSize: 40, color: Colors.blue),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Xyzon Ezekiel R. Marasigan',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text('0992345909'),
                  const Text('xyzonmarasigan98@gmail.com'),
                  const SizedBox(height: 16),
                  const Card(
                    margin: EdgeInsets.symmetric(horizontal: 8),
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Text(
                        'As a graduate of Computer Science, I am deeply passionate about the ever-evolving realm of technology. Armed with a solid understanding of programming languages and core computer science principles, I am eager to tackle challenges and apply my skills in practical projects. My approach is rooted in creative problem-solving, adaptability, and effective communication, qualities that I bring to collaborative teams.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // CV Sections
          Expanded(
            flex: 3,
            child: Container(
              color: Colors.blue[50],
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const SectionTitle(title: 'Education'),
                  const CVItem(
                    title: 'Secondary School',
                    subtitle: 'Balayan Senior High School',
                    date: '2020-2022',
                  ),
                  const CVItem(
                    title: 'Tertiary School',
                    subtitle:
                        'BS in Computer Science\nBatangas State University',
                    date: '2022-2026',
                  ),
                  const SizedBox(height: 16),
                  const SectionTitle(title: 'Skills'),
                  const BulletList(
                    items: [
                      'Project Management Skills',
                      'Pleasing Attitude',
                      'Negotiation',
                      'Critical Thinking',
                      'Active Listening',
                      'Communication Skills',
                      'Hard Worker',
                      'Social Media Proficiency',
                      'Flexible',
                      'Driving',
                    ],
                  ),
                  const SizedBox(height: 16),
                  const SectionTitle(title: 'Experience'),
                  const CVItem(
                    title: 'Social Media Moderator',
                    subtitle: 'Xterner Studios',
                    date: '2021-2022',
                    description:
                        'Social Media Moderator in a group page of my old school in a student organization.',
                  ),
                  const CVItem(
                    title: 'Domino\'s Service Crew',
                    subtitle: 'Counter, Pizza Maker, Inventory',
                  ),
                  const CVItem(
                    title: 'Domino\'s Delivery Rider',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({required this.title, super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: const TextStyle(
            fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
      ),
    );
  }
}

class CVItem extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? date;
  final String? description;
  const CVItem(
      {required this.title,
      this.subtitle,
      this.date,
      this.description,
      super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(subtitle!, style: const TextStyle(color: Colors.black54)),
          ],
          if (date != null) ...[
            const SizedBox(height: 4),
            Text(date!, style: const TextStyle(color: Colors.black45)),
          ],
          if (description != null) ...[
            const SizedBox(height: 8),
            Text(description!),
          ],
        ],
      ),
    );
  }
}

class BulletList extends StatelessWidget {
  final List<String> items;
  const BulletList({required this.items, super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items
          .map(
            (item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  const Icon(Icons.circle, size: 8, color: Colors.black54),
                  const SizedBox(width: 8),
                  Expanded(child: Text(item)),
                ],
              ),
            ),
          )
          .toList(),
    );
  }
}
