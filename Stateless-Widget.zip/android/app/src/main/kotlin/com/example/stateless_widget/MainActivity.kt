package com.example.stateless_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
